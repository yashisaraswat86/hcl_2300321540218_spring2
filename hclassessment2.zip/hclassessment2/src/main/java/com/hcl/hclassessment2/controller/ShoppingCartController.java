package com.hcl.hclassessment2.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
public class ShoppingCartController {
    @PostMapping("/add/{customerId}/{productId")
    public  void addProductToCart(@PathVariable Long customerId, @PathVariable Long productId){

    }
    @GetMapping("/{customerId}")
    public void viewCart(@PathVariable Long customerId){
    }
    @PutMapping("/{cartItemId}")
    public void updateCartItem(@PathVariable Long cartItemId){
    }
    @DeleteMapping("/remove/{cartItemId}")
    public void removeCartItem(@PathVariable Long cartItemId){

    }
    @DeleteMapping("/clear/{customerId}")
    public void clearCart(@PathVariable Long customerId){

    }
}
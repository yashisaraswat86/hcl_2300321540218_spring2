package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne; // Added for relationship mapping
import jakarta.persistence.JoinColumn; // Added for database foreign key mapping

import java.time.LocalDate;

@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cartid;

    @OneToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    private LocalDate createDate;


    public Long getCartid() {
        return cartid;
    }

    public void setCartid(Long cartid) {
        this.cartid = cartid;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }


    public LocalDate getCreateDate() {
        return createDate;
    }


    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }
}


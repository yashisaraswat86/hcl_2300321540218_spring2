package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class CustomerOrder {
    @Id
    private Long orderId ;
    private Customer customer ;
    private LocalDateTime orderDate ;
    private Double totalAmount ;
    private String orderStatus ;
}

package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class OrderItem {
    @Id
   private Long orderItemId ;
   private CustomerOrder customerOrder ;
   private Product product ;
   private int quantity ;
   private Double price ;
}

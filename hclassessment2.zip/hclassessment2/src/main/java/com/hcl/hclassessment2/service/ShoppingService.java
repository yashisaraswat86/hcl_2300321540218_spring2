package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.entity.Cart;
import com.hcl.hclassessment2.entity.Customer;
import com.hcl.hclassessment2.entity.Product;

import java.util.List;

public interface ShoppingService {
    // Customer
    Customer registerCustomer(Customer customer);
    List<Customer> getAllCustomers();
    Customer getCustomerById(Long id);
    Customer updateCustomer(Long id, Customer customer);
    void deleteCustomer(Long id);

    // Product
    Product addProduct(Product product);
    List<Product> getAllProducts();
    Product getProductById(Long id);
    Product updateProduct(Long id, Product product);
    void deleteProduct(Long id);
    List<Product> getProductsByCategory(String category);

    // Cart
    void addProductToCart(Long customerId, Long productId, int quantity);
    Cart getCartByCustomerId(Long customerId);
    void updateCartItemQuantity(Long cartItemId, int quantity);
    void removeCartItem(Long cartItemId);
    void clearCart(Long customerId);
}
